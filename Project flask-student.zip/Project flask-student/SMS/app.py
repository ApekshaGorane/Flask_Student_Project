from flask import *
from dbm import *

app=Flask(__name__)

@app.route("/")
def home():
    return render_template("home.html")

@app.route("/login")
def log():
    return render_template("login.html")

@app.route("/admin_login")
def login():
    user=request.args.get('user')
    pwd=request.args.get('pwd')
    d=get_log()
    for (user,pwd) in d:
        print("Login Successfully")
        return render_template("viewdetails.html")
    else:
        print("Invalid username or password")
        return render_template("login.html")

@app.route("/studlist")
def studlist():
    d=show()
    return render_template("viewdetails.html",data=d)

@app.route("/reg")
def register():
    return render_template("Student_register.html")

@app.route("/insertdetails",methods=["POST"])
def addstudent():
    id=request.form["sid"]
    name=request.form["sname"]
    dob=request.form["sdate"]
    city=request.form["scity"]
    phoneno=request.form["scontact"]

    t=(id,name,dob,city,phoneno)
    insertdetails(t)

    return redirect("/")

@app.route("/update")
def update():
    id=request.args.get('S_ID')
    d=selectbyid(id)
    return render_template("update.html",sdata=d)

@app.route("/updatedetails",methods=["POST"])
def updatestud():
    id=request.form["id"]
    name=request.form["name"]
    dob=request.form["dob"]
    city=request.form["city"]
    phoneno=request.form["phone"]
    

    t=(name,dob,city,phoneno,id)
    updatedetails(t)

    return redirect("/studlist")
    

@app.route("/deletedetails")
def delete():
    id=request.args.get('S_ID')
    deletedetails(id)

    return redirect("/studlist")



if __name__=="__main__":
    app.run(debug=True)

