import pymysql as p            

def getConnection():
    return p.connect(host='localhost',user='root',password='',database='student')

def login():
    db=getConnection()
    cur=db.cursor()
    sql="select email,passw from student_info"
    cur.execute(sql)
    d=cur.fetchall()
    db.commit()
    db.close()
    return d

def show():
    db=getConnection()
    cur=db.cursor()
    sql="select * from student_info"
    cur.execute(sql)
    data=cur.fetchall()
    db.commit()
    db.close()
    return data
    
def insertdetails(t):
    db=getConnection()
    cur=db.cursor()
    sql="insert into student_info values (%s,%s,%s,%s,%s)"
    cur.execute(sql,t)
    data=cur.fetchall()
    db.commit()
    db.close()
    return data

def updatedetails(t):
    db=getConnection()
    cur=db.cursor()
    sql="update student_info set NAME=%s,DOB=%s,CITY=%s,CONTACT_NO=%s where S_ID=%s"
    cur.execute(sql,t)
    data=cur.fetchall()
    db.commit()
    db.close()
    return data

def selectbyid(S_ID):
    db=getConnection()
    cur=db.cursor()
    sql="select * from student_info where S_ID=%s"
    cur.execute(sql,S_ID)
    data=cur.fetchall()
    db.commit()
    db.close()
    return data[0]


def deletedetails(S_ID):
    db=getConnection()
    sql='delete from student_info where S_ID=%s'
    cur=db.cursor()
    cur.execute(sql,S_ID)
    db.commit()
    db.close()

def get_log():
    db=get.getConnection()
    cur=db.cursor()
    sql="select username,password from admin"
    cur.execute(sql)
    data=cur.fetchall()
    db.commit()
    db.close()
    return data



    